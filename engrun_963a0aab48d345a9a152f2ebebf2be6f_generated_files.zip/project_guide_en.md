# Project Guide - Meu Sistema

## 1. Open your IDE

Open the target repository or create an empty folder for the generated project.

## 2. Create the folders

Create the folders listed below before pasting the generated files.

- `src\pcbagent\generated\agent_orchestrator`
- `src\pcbagent\generated\api`
- `src\pcbagent\generated\core_runtime`
- `src\pcbagent\generated\observability`
- `src\pcbagent\generated\plugin_runtime`
- `src\pcbagent\generated\task_manager`
- `src\pcbagent\generated\workflow_engine`
- `tests\generated`

## 3. Create and paste the generated files

### src/pcbagent/generated/core_runtime/__init__.py

Purpose: Starter module package for core_runtime.

Paste the generated content into this file.

### src/pcbagent/generated/core_runtime/coreruntimemodule.py

Purpose: Starter class for module core_runtime.

Paste the generated content into this file.

### tests/generated/test_core_runtime.py

Purpose: Starter pytest coverage for module core_runtime.

Paste the generated content into this file.

### src/pcbagent/generated/agent_orchestrator/__init__.py

Purpose: Starter module package for agent_orchestrator.

Paste the generated content into this file.

### src/pcbagent/generated/agent_orchestrator/agentorchestratormodule.py

Purpose: Starter class for module agent_orchestrator.

Paste the generated content into this file.

### tests/generated/test_agent_orchestrator.py

Purpose: Starter pytest coverage for module agent_orchestrator.

Paste the generated content into this file.

### src/pcbagent/generated/workflow_engine/__init__.py

Purpose: Starter module package for workflow_engine.

Paste the generated content into this file.

### src/pcbagent/generated/workflow_engine/workflowenginemodule.py

Purpose: Starter class for module workflow_engine.

Paste the generated content into this file.

### tests/generated/test_workflow_engine.py

Purpose: Starter pytest coverage for module workflow_engine.

Paste the generated content into this file.

### src/pcbagent/generated/task_manager/__init__.py

Purpose: Starter module package for task_manager.

Paste the generated content into this file.

### src/pcbagent/generated/task_manager/taskmanagermodule.py

Purpose: Starter class for module task_manager.

Paste the generated content into this file.

### tests/generated/test_task_manager.py

Purpose: Starter pytest coverage for module task_manager.

Paste the generated content into this file.

### src/pcbagent/generated/plugin_runtime/__init__.py

Purpose: Starter module package for plugin_runtime.

Paste the generated content into this file.

### src/pcbagent/generated/plugin_runtime/pluginruntimemodule.py

Purpose: Starter class for module plugin_runtime.

Paste the generated content into this file.

### tests/generated/test_plugin_runtime.py

Purpose: Starter pytest coverage for module plugin_runtime.

Paste the generated content into this file.

### src/pcbagent/generated/observability/__init__.py

Purpose: Starter module package for observability.

Paste the generated content into this file.

### src/pcbagent/generated/observability/observabilitymodule.py

Purpose: Starter class for module observability.

Paste the generated content into this file.

### tests/generated/test_observability.py

Purpose: Starter pytest coverage for module observability.

Paste the generated content into this file.

### src/pcbagent/generated/api/system.py

Purpose: Starter FastAPI router for system status.

Paste the generated content into this file.

### tests/generated/test_system_api.py

Purpose: Starter pytest coverage for the generated API router.

Paste the generated content into this file.

## 4. Add the generated tests

- Create `tests/generated/test_coreruntimemodule.py` and paste the generated test content.
- Create `tests/generated/test_agentorchestratormodule.py` and paste the generated test content.
- Create `tests/generated/test_workflowenginemodule.py` and paste the generated test content.
- Create `tests/generated/test_taskmanagermodule.py` and paste the generated test content.
- Create `tests/generated/test_pluginruntimemodule.py` and paste the generated test content.
- Create `tests/generated/test_observabilitymodule.py` and paste the generated test content.
- Create `tests/generated/test_system.py` and paste the generated test content.

## 5. Review architecture and refactor recommendations

Meu Sistema should be implemented as a modular platform guided by Clean Architecture, Modular, Event Driven, Agent Oriented, Plugin Based. The initial system should center on core_runtime, agent_orchestrator, workflow_engine, task_manager, plugin_runtime, observability, keeping orchestration, workflow execution and extensibility behind stable boundaries.

0 refactor actions proposed from 0 findings.

## 6. Validate the project

Run the generated tests and inspect the self-improvement report before committing the code.